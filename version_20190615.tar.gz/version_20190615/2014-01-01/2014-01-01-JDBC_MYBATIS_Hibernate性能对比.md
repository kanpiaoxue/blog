#JDBC，MYBATIS，Hibernate性能对比！
###发表时间：2014-01-01
###分类：java
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1998002" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1998002</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;">
 <p>来源:&nbsp;http://www.cnblogs.com/softman11/archive/2013/04/06/3001874.html</p>
</div>