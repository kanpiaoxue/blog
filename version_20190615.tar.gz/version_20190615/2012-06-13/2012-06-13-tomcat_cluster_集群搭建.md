#tomcat cluster 集群搭建
###发表时间：2012-06-13
###分类：tomcat
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1560016" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1560016</a>

---

<p>写了一个用tomcat7 做cluster的例子。请参看附件中的 pdf 文档</p>