#ssh-keygen生成秘钥对
###发表时间：2018-12-08
###分类：mac,经验,ssh-keygen,Linux
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2434920" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2434920</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>参考资料：</p> 
 <p>Connecting to GitHub with SSH：<a href="https://help.github.com/articles/connecting-to-github-with-ssh/">https://help.github.com/articles/connecting-to-github-with-ssh/</a></p> 
 <p>&nbsp;</p> 
 <pre name="code" class="java">ssh-keygen -t rsa -f helloworld -C "helloworld public-private-keys"</pre> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
</div>