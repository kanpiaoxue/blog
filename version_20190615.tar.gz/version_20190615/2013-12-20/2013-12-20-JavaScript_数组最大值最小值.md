#JavaScript 数组最大值最小值
###发表时间：2013-12-20
###分类：javascript
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1993011" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1993011</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <pre name="code" class="js">/**
 * &lt;pre&gt;
 * @param arr
 * @returns 返回数字数组arr中的最大值
 * &lt;/pre&gt;
 */
function getMaxFromArray(arr){
	return Math.max.apply(null, arr);
}
/**
 * &lt;pre&gt;
 * @param arr
 * @returns 返回数字数组arr中的最小值
 * &lt;/pre&gt;
 */
function getMinFromArray(ar){
	return Math.min.apply(null, arr);
}</pre> 
 <p>&nbsp;</p> 
</div>