#sprintboot mybatis mutli datasource 多数据问题
###发表时间：2019-03-06
###分类：Spring,springboot,java,mybatis
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2438526" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2438526</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>参考资料：</p> 
 <p>（*重点参考*）&nbsp;<a href="https://github.com/mybatis/spring-boot-starter/issues/78">https://github.com/mybatis/spring-boot-starter/issues/78</a></p> 
 <p>（*重点参考*）&nbsp;<a href="https://stackoverflow.com/questions/45941125/transaction-not-working-on-multi-datasource-spring-boot-mybatis-application">https://stackoverflow.com/questions/45941125/transaction-not-working-on-multi-datasource-spring-boot-mybatis-application</a></p> 
 <p><a href="https://xli1224.github.io/2018/03/11/spring-mybatis-multiple-datasource/">https://xli1224.github.io/2018/03/11/spring-mybatis-multiple-datasource/</a></p> 
 <p>参考代码： <a href="https://github.com/kazuki43zoo/mybatis-spring-boot-multi-ds-demo">https://github.com/kazuki43zoo/mybatis-spring-boot-multi-ds-demo</a></p> 
</div>