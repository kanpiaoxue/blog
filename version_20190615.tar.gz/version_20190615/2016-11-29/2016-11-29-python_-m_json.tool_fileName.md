#python -m json.tool fileName
###发表时间：2016-11-29
###分类：python,非技术,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2341798" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2341798</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>&nbsp;命令：&nbsp;<span style="background-color: #fafafa; font-family: monospace;">python -m json.tool fileName 可以将fileName里的json字符串进行格式化。命令如下：</span></p> 
 <p>&nbsp;</p> 
 <pre name="code" class="python">python -m json.tool C:\Users\kpx\Desktop\new1.tmp.txt</pre> 
 <p>&nbsp;</p> 
</div>