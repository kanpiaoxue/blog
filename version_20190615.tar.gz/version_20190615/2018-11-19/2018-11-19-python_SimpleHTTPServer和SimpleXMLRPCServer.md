#python SimpleHTTPServer和SimpleXMLRPCServer
###发表时间：2018-11-19
###分类：python
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2434037" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2434037</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>python有2个非常有用的内置服务器：</p> 
 <p>SimpleHTTPServer和SimpleXMLRPCServer</p> 
</div>