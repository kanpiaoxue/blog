#Ext Treepanel 刷新
###发表时间：2013-12-25
###分类：javascript,Ext
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1995134" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1995134</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <pre name="code" class="java">Ext.getCmp(treeId).root.reload();</pre> 
 <p>&nbsp;</p> 
</div>