#springboot的logback的默认配置文件位置
###发表时间：2018-09-11
###分类：java,springboot,log
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2430460" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2430460</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>springboot的logback的默认配置文件位置：</p> 
 <div class="quote_div">
  spring-boot-2.0.4.RELEASE.jar/org/springframework/boot/logging/logback/defaults.xml
 </div> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
</div>