#pip install 安装指定版本的包
###发表时间：2018-09-05
###分类：python,pip
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2430095" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2430095</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>安装 pyhive的0.3.0版本</p> 
 <p>pip install PyHive==0.3.0</p> 
 <p>&nbsp;</p> 
 <p>安装 pyhive的最新版本</p> 
 <p>pip install PyHive</p> 
 <p>&nbsp;</p> 
 <p>如何查看pyhive的版本呢？</p> 
 <p>安装完成pyhive之后进入目录&nbsp;python2.7/site-packages/pyhive 查看里面的文件__init__.py ，里面有版本信息：</p> 
 <div class="quote_title">
  写道
 </div> 
 <div class="quote_div">
  $cat __init__.py
  <br>from __future__ import absolute_import
  <br>from __future__ import unicode_literals
  <br>__version__ = '0.3.0'
 </div> 
 <p>&nbsp;</p> 
</div>