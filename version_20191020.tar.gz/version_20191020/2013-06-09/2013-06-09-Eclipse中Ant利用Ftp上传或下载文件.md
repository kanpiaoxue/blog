#Eclipse中Ant利用Ftp上传或下载文件
###发表时间：2013-06-09
###分类：ant
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1884765" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1884765</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p><a href="http://wenku.baidu.com/view/4b4f9418cc7931b765ce153a.html">http://wenku.baidu.com/view/4b4f9418cc7931b765ce153a.html</a></p> 
</div>