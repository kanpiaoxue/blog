#Linux 安装 Python
###发表时间：2016-07-12
###分类：python,Linux
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2310840" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2310840</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>------- Linux 安装 Python</p> 
 <p>-- python.org 下载</p> 
 <p>-- 解压</p> 
 <p>#tar xvf Python-2.7.2.tar.bz2</p> 
 <p>-- 安装</p> 
 <p>#cd Python-2.7.2</p> 
 <p>#./configure</p> 
 <p>#make &amp;&amp; make install</p> 
 <p>--完成</p> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>上面是极为简单的安装，更多信息参考一下官网吧：www.<span style="line-height: 1.5;">python.org</span></p> 
</div>