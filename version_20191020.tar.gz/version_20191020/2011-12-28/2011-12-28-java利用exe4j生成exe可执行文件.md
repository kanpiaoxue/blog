#java利用exe4j生成exe可执行文件
###发表时间：2011-12-28
###分类：exe4j
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1328901" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1328901</a>

---

<p>引自：</p>
<p><a href="http://ykdn2010.iteye.com/blog/1238889">http://ykdn2010.iteye.com/blog/1238889</a></p>
<p>&nbsp;</p>
<p>exe4j 当前版本，添加jar包的时候，只能一个个添加，很是繁琐。</p>
<p>这个exe4j觉得很失败。因为走到什么地方都要带着jre，好几十兆。或者必须要jre环境。太恶心了。有没有好的生成exe的东东，推荐一下啊</p>