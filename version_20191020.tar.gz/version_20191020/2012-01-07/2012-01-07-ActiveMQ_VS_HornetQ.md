#ActiveMQ VS HornetQ
###发表时间：2012-01-07
###分类：HornetQ,ActiveMQ
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1337069" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1337069</a>

---

<p><a href="http://topmanopensource.iteye.com/blog/1070622">http://topmanopensource.iteye.com/blog/1070622</a></p>