#table td 边框 设置 border-collapse: collapse;cellspacing:0;
###发表时间：2010-04-26
###分类：
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/653400" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/653400</a>

---

<pre name="code" class="html">&lt;html&gt;
&lt;head&gt;

&lt;style type="text/css"&gt;

body {background-color: yellow}

table {
  width:400px;
  border-collapse: collapse;
  cellspacing:0;
}
td{
 border: 1 solid black;
}
&lt;/style&gt;

&lt;/head&gt;

&lt;body&gt;
&lt;table&gt;
&lt;tr&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;td&gt;&amp;nbsp;
&lt;/td&gt;
&lt;/tr&gt;
&lt;/table&gt;


&lt;/body&gt;
&lt;/html&gt;
</pre>
<p>&nbsp;<br><br>&nbsp;&nbsp;<br><br>&nbsp;&nbsp;<br><br>&nbsp;&nbsp;<br><br>&nbsp;&nbsp;<br><br>&nbsp;&nbsp;<br><br>&nbsp;&nbsp;<br><br>&nbsp;&nbsp;<br><br><br><br><br>&nbsp;</p>
<p>&nbsp;</p>