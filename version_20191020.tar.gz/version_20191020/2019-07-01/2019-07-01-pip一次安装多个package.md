#pip一次安装多个package
###发表时间：2019-07-01
###分类：pip,python
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2442290" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2442290</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>在一个pip的命令行里面可以同时指定安装多个package。如下：</p> 
 <pre name="code" class="java">pip install gevent==1.4.0 sh==1.12.14 thrift==0.10.0 thrift-sasl==0.2.0 requests==2.22.0 ssh==1.8.0 pyhs2==0.6.0 openpyxl==2.6.2 PyHive==0.6.1 MySQL-python==1.2.5</pre> 
 <p>&nbsp;</p> 
</div>