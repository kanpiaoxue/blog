#Eclipse中配置Ehcache提示信息
###发表时间：2018-02-28
###分类：eclipse,经验,非技术,ehcache
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2411817" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2411817</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>使用eclipse开发ehcache的时候总是提示在加载<span style="color: #555555;">ehcache.xsd。</span></p> 
 <p><span style="color: #555555;">解决方案：</span></p> 
 <p><a href="http://blog.csdn.net/qq_30930805/article/details/70840312"><span style="color: #555555;">http://blog.csdn.net/qq_30930805/article/details/70840312</span></a></p> 
</div>