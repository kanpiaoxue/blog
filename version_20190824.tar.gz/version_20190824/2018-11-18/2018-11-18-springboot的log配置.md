#springboot的log配置
###发表时间：2018-11-18
###分类：springboot,Spring,java,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2433970" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2433970</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>如何只引入springboot的log配置呢？如下：</p> 
 <pre name="code" class="xml">&lt;dependency&gt;
	&lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
	&lt;artifactId&gt;spring-boot-starter-logging&lt;/artifactId&gt;
&lt;/dependency&gt;</pre> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
</div>