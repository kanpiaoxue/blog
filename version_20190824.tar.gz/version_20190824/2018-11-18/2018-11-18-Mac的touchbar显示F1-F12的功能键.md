#Mac的touchbar显示F1-F12的功能键
###发表时间：2018-11-18
###分类：mac,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2433982" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2433982</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>参考地址：<a href="https://segmentfault.com/a/1190000011419849">https://segmentfault.com/a/1190000011419849</a></p> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p style="">新款mbp虽加上了炫酷的touchbar，但是用起快捷键贼难受。</p> 
 <p style="">基本用法是按住fn键就会出现f1-f12，这样的话原本两个键的快捷键，现在得按三个键，按起来贼难受。<br style="">有没有方法让touchbar在编辑器里一直显示fn键呢？google一搜轻松找到答案。</p> 
 <p style="">&nbsp;</p> 
 <p style="">Mac的系统偏好设置 -&gt; 键盘 -&gt; 键盘&nbsp;</p> 
 <p style="">触控栏显示：F1、F2等键</p> 
 <p style="">按下Fn键以：展开功能栏</p> 
 <p style="">&nbsp;</p> 
 <p style="">如上的操作即可。</p> 
 <p style="">&nbsp;</p> 
</div>