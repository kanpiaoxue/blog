#spring quartz 2.x
###发表时间：2014-01-12
###分类：java,Spring
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2003101" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2003101</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>spring3.1 开始支持Quartz2.x</p> 
 <p>具体如何做呢？我找了两篇帖子，不过没有具体操作。等用到了再去试验，这里先收藏了。</p> 
 <p>参考地址：</p> 
 <p><a href="http://shellblog.sinaapp.com/?p=395">http://shellblog.sinaapp.com/?p=395</a></p> 
 <p><a href="http://www.oschina.net/question/97503_87765">http://www.oschina.net/question/97503_87765</a></p> 
</div>