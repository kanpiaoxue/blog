#Eclipse 中给项目自动创建ant的build.xml文件
###发表时间：2012-07-31
###分类：ant,java
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1613150" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1613150</a>

---

<p><span style="font-family: simsun; font-size: 14px; line-height: 21px; text-align: left; background-color: #ffffff;">Eclipse 自动生成 Ant的Build.xml 配置文件,生成的方法很隐蔽</span> </p>
<p style="margin-bottom: 5px; line-height: 21px; font-family: simsun; font-size: 14px; text-align: left; padding: 0px;"><span style="background-color: #ffffff;">选择你要生成Build.xml文件的项目,右键. Export-&gt; General -&gt; Ant Buildfiles .</span></p>
<p style="margin-bottom: 5px; line-height: 21px; font-family: simsun; font-size: 14px; text-align: left; padding: 0px;"><span style="background-color: #ffffff;">点Next,再点Finish.</span></p>
<p style="margin-bottom: 5px; line-height: 21px; font-family: simsun; font-size: 14px; text-align: left; padding: 0px;"><span style="background-color: #ffffff;">生成完毕.</span></p>
<p style="margin-bottom: 5px; line-height: 21px; font-family: simsun; font-size: 14px; text-align: left; padding: 0px;"><span style="background-color: #ffffff;">&nbsp;</span></p>
<p style="margin-bottom: 5px; line-height: 21px; font-family: simsun; font-size: 14px; text-align: left; padding: 0px;"><span style="background-color: #ffffff;">希望使用的可以试试了。总算不用再傻傻的自己编写build.xml了。</span></p>
<p style="margin-bottom: 5px; line-height: 21px; font-family: simsun; font-size: 14px; text-align: left; padding: 0px;">&nbsp;</p>
<p style="margin-bottom: 5px; line-height: 21px; font-family: simsun; font-size: 14px; text-align: left; padding: 0px;">引用自：&nbsp;<a style="font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px;" href="http://blog.sina.com.cn/s/blog_53a99cf30100f4ci.html">http://blog.sina.com.cn/s/blog_53a99cf30100f4ci.html</a></p>