#How to customise file type to syntax associations in Sublime Text?
###发表时间：2019-03-19
###分类：sublime,经验,mac,非技术
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2439047" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2439047</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>In Sublime Text (confirmed in both v2.x and v3.x) there is a menu command:</p> 
 <pre name="code" class="java">View -&gt; Syntax -&gt; Open all with current extension as ...</pre> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
</div>