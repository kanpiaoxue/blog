#Eclipse 安装最新SVN插件
###发表时间：2014-05-07
###分类：eclipse,myeclipse
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2063448" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2063448</a>

---

<div class="iteye-blog-content-contain"> 
 <p style="font-size: 14px;"><a style="line-height: 1.5;" href="http://liujianqiao398.blog.163.com/blog/static/181827257201331194610634/">Eclipse 安装最新SVN插件&nbsp;</a>：引自：<a href="http://liujianqiao398.blog.163.com/blog/static/181827257201331194610634/">&nbsp;Eclipse 安装最新SVN插件&nbsp;</a></p> 
 <h1 style="margin-bottom: 0px; font-size: 16pt; font-family: 微软雅黑, Verdana, sans-serif, 宋体; line-height: normal;"> <a style="padding: 0px; margin: 0px; color: #000000;" name="top" href="http://www.oschina.net/question/158170_34997">myeclipse安装svn插件的多种方式</a>：引自：<a href="http://www.oschina.net/question/158170_34997/">&nbsp;http://www.oschina.net/question/158170_34997/</a> </h1> 
 <p style="font-size: 14px;"><strong><span style="color: #ff0000;">具体内容请看附件</span></strong></p> 
 <p style="font-size: 14px;">&nbsp;</p> 
 <p style="font-size: 14px;">&nbsp;</p> 
 <p style="font-size: 14px;"><strong><span style="color: #ff0000;">-------------------------------------------------------------</span></strong></p> 
 <p><strong style="font-size: 14px;"><span style="color: #ff0000;">&nbsp;到官网：&nbsp;</span></strong><span style="color: #ff0000;"><strong><a href="http://subclipse.tigris.org/">http://subclipse.tigris.org/</a>&nbsp;下载相应的安装 zip 文件，解压之后，将整个解压到文件夹，放到eclipse 下面的 dropins 里面。启动Eclipse，就可以使用了。</strong></span></p> 
</div>