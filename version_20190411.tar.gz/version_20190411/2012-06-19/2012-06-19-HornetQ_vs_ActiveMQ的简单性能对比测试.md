#HornetQ vs ActiveMQ的简单性能对比测试
###发表时间：2012-06-19
###分类：ActiveMQ,HornetQ
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1564094" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1564094</a>

---

<p>自己做的“HornetQ vs ActiveMQ的简单性能对比测试”。只测试了hornetq和activemq的发送，没有测试接收。</p>
<p>测试结果请看附件的pdf</p>