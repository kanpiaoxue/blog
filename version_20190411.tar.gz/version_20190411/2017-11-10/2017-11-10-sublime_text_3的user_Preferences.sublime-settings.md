#sublime text 3的user Preferences.sublime-settings
###发表时间：2017-11-10
###分类：sublime,经验,mac
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2399310" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2399310</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <pre name="code" class="java">{
	"auto_complete_triggers":
	[
		{
			"characters": "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.&lt;",
			"selector": "text.html"
		},
		{
			"characters": "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.&lt;",
			"selector": "text.xml"
		},
		{
			"characters": "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.&lt;",
			"selector": "text.css"
		},
		{
			"characters": "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.&lt;",
			"selector": "text.js"
		}
	],
	"bold_folder_labels": true,
	"color_scheme": "Packages/JavaScriptNext - ES6 Syntax/Monokai Phoenix.tmTheme",
	"font_size": 15,
	"highlight_line": true,
	"ignored_packages":
	[
		"Vintage"
	],
	"open_files_in_new_window": false,
	"save_on_focus_lost": true,
	"scroll_past_end": true,
	"show_encoding": true,
	"show_full_path": true,
	"show_line_endings": true,
	"translate_tabs_to_spaces": true,
	"trim_trailing_white_space_on_save": true
}
</pre> 
 <p>&nbsp;</p> 
</div>