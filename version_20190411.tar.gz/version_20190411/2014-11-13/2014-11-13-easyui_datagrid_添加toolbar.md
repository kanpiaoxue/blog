#easyui datagrid 添加toolbar
###发表时间：2014-11-13
###分类：jQuery,easyui,javascript
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2155540" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2155540</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>[</p> 
 <p>{ text: '增加', iconCls: 'icon-add', handler: function () { &nbsp;} },</p> 
 <p>{ text: '修改', iconCls: 'icon-edit', handler: function () { } },</p> 
 <p>{ text: '删除', iconCls: 'icon-remove', handler: function () { } },</p> 
 <p>{ text: '查看', handler: function () { } }, '-',</p> 
 <p>{ text: '刷新', iconCls: 'icon-reload', handler: function () { &nbsp;} },</p> 
 <p>{ text: '导出', iconCls: 'icon-save', handler: function () { &nbsp;} }, '-'],</p> 
</div>