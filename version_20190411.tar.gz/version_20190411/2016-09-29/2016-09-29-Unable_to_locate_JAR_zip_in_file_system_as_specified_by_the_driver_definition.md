#Unable to locate JAR/zip in file system as specified by the driver definition
###发表时间：2016-09-29
###分类：eclipse,mybatis,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2327921" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2327921</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;">
 <p><span style="color: #444444; font-family: 'Microsoft YaHei', Tahoma, Helvetica, SimSun, sans-serif; font-size: 16px;">在eclipse的“Data Source Explorer”弹出对话框中选一个driver，如果出现“Unable to locate JAR/zip in file system as specified by the driver definition: xxx.jar.”</span><span class="jammer" style="font-size: 10px; color: #ffffff; font-family: 'Microsoft YaHei', Tahoma, Helvetica, SimSun, sans-serif;">3 |: |% W) b! i&amp; x0 d</span><br style="color: #444444; font-family: 'Microsoft YaHei', Tahoma, Helvetica, SimSun, sans-serif;"><span style="color: #444444; font-family: 'Microsoft YaHei', Tahoma, Helvetica, SimSun, sans-serif; font-size: 16px;">就要在“JAR List”选项卡中删除原有的驱动文件，重新加一下就好了。</span></p>
</div>