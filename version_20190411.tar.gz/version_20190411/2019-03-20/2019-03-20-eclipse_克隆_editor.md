#eclipse 克隆 editor
###发表时间：2019-03-20
###分类：eclipse,经验,非技术
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2439097" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2439097</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>有的时候我们希望能将一个eclipse的editor进行克隆，这样我们可以看着同一份代码的不同部分（尤其当前代码行数比较多的时候）。</p> 
 <p>怎么克隆eclipse的editor呢？</p> 
 <p>很简单，eclipse就提供了editor的克隆功能。</p> 
 <p>菜单栏顺序：Window --&gt; Editor --&gt; Clone按钮。 这样就可以克隆当前的editor。</p> 
 <p>我们还可以进入eclipse的keys设定快捷键，方便操作。</p> 
 <p>&nbsp;</p> 
 <p>参考： 《Split and Clone Editor Views in Eclipse》<a href="https://mcuoneclipse.com/2016/06/11/split-and-clone-editor-views-in-eclipse/">https://mcuoneclipse.com/2016/06/11/split-and-clone-editor-views-in-eclipse/</a></p> 
</div>