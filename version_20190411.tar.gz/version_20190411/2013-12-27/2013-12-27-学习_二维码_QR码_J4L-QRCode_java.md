#学习：二维码、QR码、J4L-QRCode、java
###发表时间：2013-12-27
###分类：java
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1996601" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1996601</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <h3 style="font-size: 16px; padding-top: 10px;"><a style="color: #108ac6; text-decoration: underline;" href="http://baijinshan.iteye.com/blog/1004554">学习：二维码、QR码、J4L-QRCode、java</a></h3> 
 <p>来源：<a style="font-size: 12px; line-height: 1.5;" href="http://baijinshan.iteye.com/blog/1004554">http://baijinshan.iteye.com/blog/1004554</a></p> 
</div>