#Redis安装整理(window平台和Linux平台)
###发表时间：2013-12-25
###分类：redis
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1995264" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1995264</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <h3 style="font-size: 16px; padding-top: 10px;"><a style="color: #108ac6; text-decoration: underline;" href="http://zheng12tian.iteye.com/blog/1471726">Redis安装整理(window平台和Linux平台)</a></h3> 
 <p>地址：&nbsp;<a style="font-size: 12px; line-height: 1.5;" href="http://zheng12tian.iteye.com/blog/1471726">http://zheng12tian.iteye.com/blog/1471726</a></p> 
</div>