#Mac 中 sublime 打开文件的方式改为 in new tab
###发表时间：2017-08-31
###分类：mac,sublime,非技术,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2391718" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2391718</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>在 mac 中使用 sublime 的时候，在 finder 中双击一个默认采用 sublime 打开的文件，sublime 会新开一个窗口。这种体验很不好，我更喜欢打开一个新的 tab 而不是一个新的 window。</p> 
 <p>操作如下：</p> 
 <div class="quote_title">
  command + , 快捷键打开配置文件&nbsp;
 </div> 
 <div class="quote_div">
  "open_files_in_new_window": false
 </div> 
 <p>&nbsp;配置之后，双击文件就会以新的 tab 打开了。</p> 
 <p>&nbsp;</p> 
</div>