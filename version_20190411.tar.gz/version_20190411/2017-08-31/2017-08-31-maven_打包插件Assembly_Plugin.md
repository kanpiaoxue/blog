#maven 打包插件Assembly Plugin
###发表时间：2017-08-31
###分类：maven
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2391772" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2391772</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>地址：<a href="http://maven.apache.org/plugins/maven-assembly-plugin/index.html">&nbsp;http://maven.apache.org/plugins/maven-assembly-plugin/index.html</a></p> 
 <p>&nbsp;</p> 
 <div class="quote_title">
  打包类型 ：
 </div> 
 <div class="quote_div"> 
  <ul> 
   <li>zip</li> 
   <li>tar</li> 
   <li>tar.gz (or tgz)</li> 
   <li>tar.bz2 (or tbz2)</li> 
   <li>tar.snappy</li> 
   <li>tar.xz (or txz)</li> 
   <li>jar</li> 
   <li>dir</li> 
   <li>war</li> 
   <li>and any other format that the ArchiveManager has been configured for</li> 
  </ul> 
 </div> 
 <p>&nbsp;打包的参考：<a href="http://maven.apache.org/plugins/maven-assembly-plugin/examples/index.html">&nbsp;http://maven.apache.org/plugins/maven-assembly-plugin/examples/index.html</a></p> 
</div>