#Java API生成唯一标识字符串 UUID
###发表时间：2013-11-08
###分类：java,UUID
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1973208" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1973208</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <pre name="code" class="java">		System.out.println(UUID.randomUUID().toString());
		System.out.println(UUID.randomUUID().toString().length());
		System.out.println(UUID.randomUUID().toString().replaceAll("-", ""));
		System.out.println(UUID.randomUUID().toString().replaceAll("-", "").length());</pre> 
 <p>&nbsp;</p> 
</div>