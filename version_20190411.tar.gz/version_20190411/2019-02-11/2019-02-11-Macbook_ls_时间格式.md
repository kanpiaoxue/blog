#Macbook ls 时间格式
###发表时间：2019-02-11
###分类：Linux,经验,mac
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2437435" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2437435</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>How do I change the time format used by ls command line on osx?</p> 
 <p>回答：</p> 
 <p><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">OS X's built-in&nbsp;</span><code style="margin: 0px; padding: 1px 5px; border: 0px; line-height: inherit; font-family: Consolas, Menlo, Monaco, 'Lucida Console', 'Liberation Mono', 'DejaVu Sans Mono', 'Bitstream Vera Sans Mono', 'Courier New', monospace, sans-serif; font-size: 13px; vertical-align: baseline; background-color: #eff0f1; white-space: pre-wrap; color: #242729;">ls</code><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">&nbsp;command does not take time formatting arguments。</span></p> 
 <p><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">Mac可以使用 ls -lT</span></p> 
 <p>&nbsp;</p> 
 <p><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">参考：<a href="https://apple.stackexchange.com/questions/15170/how-do-i-change-the-time-format-used-by-ls-command-line-on-osx">&nbsp;</a></span><a href="https://apple.stackexchange.com/questions/15170/how-do-i-change-the-time-format-used-by-ls-command-line-on-osx"><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;"><span style="font-size: 15px;">https://apple.stackexchange.com/questions/15170/how-do-i-change-the-time-format-used-by-ls-command-line-on-osx</span></span></a></p> 
</div>