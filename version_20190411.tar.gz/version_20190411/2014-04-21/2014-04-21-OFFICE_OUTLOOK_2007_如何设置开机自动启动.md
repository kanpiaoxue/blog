#OFFICE OUTLOOK 2007 如何设置开机自动启动
###发表时间：2014-04-21
###分类：非技术,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2051489" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2051489</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <pre name="code" class="java">第一步：让Outlook2007最小化时在系统托盘

　　打开Outlook2007，在系统托盘的Outlook图标上右键，选中“最小化时隐藏”。

第二步：让Outlook2007开机启动

　　找到Outlook2007的快捷图标，复制。点击“开始/所有程序/启动”，在启动上右键，选择“打开”，粘贴。

第三步：让Outlook2007开机启动时最小化

　　在所有程序菜单找到刚添加的“Outlook2007“快捷图标。右键，“属性”，选择“快捷方式”选项卡，在“运行方式”下拉列表框中选择“最小化”

 

OK，大功告成了！是不是很简单呀！

其实，做过之后再想想，用这种办法可以让任何程序开机启动并最小化。

不错吧，那就顶下吧！也不枉费我打了这么时间的字！嘿嘿……</pre> 
 <p>&nbsp;</p> 
 <p>转自：&nbsp;<a href="http://www.cnblogs.com/microsoft-jiang/archive/2010/05/06/1728601.html">http://www.cnblogs.com/microsoft-jiang/archive/2010/05/06/1728601.html</a></p> 
</div>