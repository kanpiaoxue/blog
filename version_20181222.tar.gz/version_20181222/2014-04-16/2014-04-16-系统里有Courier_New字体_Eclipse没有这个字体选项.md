#系统里有Courier New字体 Eclipse没有这个字体选项
###发表时间：2014-04-16
###分类：eclipse,myeclipse
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2047373" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2047373</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <pre class="best-text mb-10">解决方法如下：
win7(xp)中的系统字体分为"显示"和"隐藏"两种状态
当为"隐藏"状态时，其它软件程序就无法找到该字体。
解决办法是把要使用的系统字体设为显示。
如：在C:/windows/Fonts中设置Courier New 字体为显示就可以了
或者从“控制面板”-&gt;“字体”，里面找到“<span style="font-size: 1em; line-height: 1.5;">Courier New”，选中这个字体，选择“显示”，就可以了。</span>
如在Fonts文件夹中没用找到Courier New，没用找到可以直接将在其它人的电脑中拷贝下来。</pre> 
</div>