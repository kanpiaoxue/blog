#eclipse添加maven的远程catalog
###发表时间：2014-07-06
###分类：java,eclipse,maven
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2088839" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2088839</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>点击菜单：Window -&gt; Preferences -&gt; Maven -&gt;&nbsp;Archetypes</p> 
 <p>点击： add remote catalog...</p> 
 <p>在Catalog File 里面输入：&nbsp;http://repo1.maven.org/maven2/archetype-catalog.xml</p> 
 <p>在Description 里面输入： archetype-catalog</p> 
 <p>参考 ：<a href="/admin/blogs/2088818">&nbsp;http://kanpiaoxue.iteye.com/admin/blogs/2088818</a></p> 
</div>