#sublime text 3 启动之后一直在运行updating npm dependencies的问题
###发表时间：2017-11-10
###分类：sublime,经验,mac
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2399252" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2399252</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>使用mac有一段时间了，也安装了开发申请sublime。为了加快开发速度，同样安装了sublime的一个插件。由于一次性安装的插件比较多，发现每次sublime text 3 启动之后一直在运行updating npm dependencies的问题，一直在运行，好像是网络不通的问题。开始以为是它依赖的插件内容的网址被强了呢。后来我在国外的网址也看见有人反馈这个问题，才确定不是网络的问题，而是有插件偷偷干什么见不得的事情。</p> 
 <p>参考地址：&nbsp;<a href="https://forum.sublimetext.com/t/updating-npm-dependencies-every-startup/25169">https://forum.sublimetext.com/t/updating-npm-dependencies-every-startup/25169</a></p> 
 <p>现在我卸载了插件“<span style="color: #222222; font-family: Helvetica, Arial, sans-serif;">&nbsp;Javascript Completions</span><span style="color: #222222; font-family: Helvetica, Arial, sans-serif;">&nbsp;”之后，这个</span><span style="color: #222222; font-family: Helvetica, Arial, sans-serif;">updating npm dependencies的问题迎刃而解。</span></p> 
 <p>&nbsp;</p> 
</div>