#OmniGranffle的背景画布自动扩展
###发表时间：2018-01-05
###分类：OmniGranffle,非技术,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2406807" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2406807</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>在使用&nbsp;OmniGranffle 的时候发现画图的内容超过了原来的画布大小，而且不自动扩展。找了好久才发现，在OmniGranffle的右侧功能面板中的Canvas的小面板中可以设置。</p> 
 <p>将里面的“Auto-adjust the canvas size”的checkbox勾选上即可。</p> 
</div>