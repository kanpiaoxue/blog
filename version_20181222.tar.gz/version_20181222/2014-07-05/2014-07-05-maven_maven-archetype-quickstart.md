#maven maven-archetype-quickstart
###发表时间：2014-07-05
###分类：java,maven
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2088526" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2088526</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>maven-archetype-quickstart</p> 
 <p>&nbsp;</p> 
 <p><a href="http://maven.apache.org/archetype/maven-archetype-bundles/maven-archetype-quickstart/">http://maven.apache.org/archetype/maven-archetype-bundles/maven-archetype-quickstart/</a></p> 
 <div class="quote_title">
  写道
 </div> 
 <div class="quote_div">
  mvn archetype:generate -DarchetypeGroupId=org.apache.maven.archetypes -DarchetypeArtifactId=maven-archetype-quickstart -DarchetypeVersion=5-SNAPSHOT
 </div> 
 <p>&nbsp;</p> 
</div>