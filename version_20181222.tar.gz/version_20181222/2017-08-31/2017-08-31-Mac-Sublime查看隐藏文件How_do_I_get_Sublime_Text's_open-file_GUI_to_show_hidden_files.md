#Mac-Sublime查看隐藏文件How do I get Sublime Text's open-file GUI to show hidden files?
###发表时间：2017-08-31
###分类：sublime,经验,mac
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2391711" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2391711</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>Mac 中要想在 sublime 里面查看或者打开隐藏文件，运行下面的快捷键即可：</p> 
 <p><kbd>&nbsp;cmd</kbd><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">&nbsp;+&nbsp;</span><kbd>&nbsp;shift</kbd><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">&nbsp;+&nbsp;</span><kbd>.</kbd><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">&nbsp;</span></p> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif; font-size: 15px;">地址：</span><a href="https://apple.stackexchange.com/questions/64324/how-do-i-get-sublime-texts-open-file-gui-to-show-hidden-files"><span style="color: #242729; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;"><span style="font-size: 15px;">https://apple.stackexchange.com/questions/64324/how-do-i-get-sublime-texts-open-file-gui-to-show-hidden-files</span></span></a></p> 
</div>