#git 查看commit的内容
###发表时间：2020-02-21
###分类：git,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2512520" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2512520</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>0.查看所有的commit提交记录</p> 
 <p>&nbsp; &nbsp; git log&nbsp;</p> 
 <p>1.查看最新的commit</p> 
 <p>&nbsp; &nbsp; git show</p> 
 <p>2.查看指定commit hashID的所有修改：</p> 
 <p>&nbsp; &nbsp; git show commitId</p> 
 <p>3.查看某次commit中具体某个文件的修改：</p> 
 <p>&nbsp; &nbsp; git show commitId fileName</p> 
 <p>&nbsp;</p> 
</div>