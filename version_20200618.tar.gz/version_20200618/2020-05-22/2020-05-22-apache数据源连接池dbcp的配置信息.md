#apache数据源连接池dbcp的配置信息
###发表时间：2020-05-22
###分类：DataSource,java,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2514255" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2514255</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p>官网文档地址：&nbsp;<a href="https://commons.apache.org/proper/commons-dbcp/configuration.html">https://commons.apache.org/proper/commons-dbcp/configuration.html</a></p> 
 <p>&nbsp;</p> 
</div>