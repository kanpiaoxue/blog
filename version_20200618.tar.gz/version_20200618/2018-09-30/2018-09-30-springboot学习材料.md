#springboot学习材料
###发表时间：2018-09-30
###分类：springboot,Spring,java,经验
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2431576" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2431576</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p style="font-size: 14px;">&nbsp;</p> 
 <p style="font-size: 14px;">入门学习资料：</p> 
 <ul style="font-size: 14px;"> 
  <li>官网文档：<a href="https://docs.spring.io/spring-boot/docs/2.0.5.RELEASE/reference/htmlsingle/">https://docs.spring.io/spring-boot/docs/2.0.5.RELEASE/reference/htmlsingle/</a> </li> 
  <li>参考样例： <a href="https://www.callicoder.com/categories/spring-boot/">https://www.callicoder.com/categories/spring-boot/</a> </li> 
  <li>参考样例：&nbsp;<a href="https://www.cnblogs.com/ityouknow/category/914493.html">https://www.cnblogs.com/ityouknow/category/914493.html</a> </li> 
 </ul> 
 <p style="font-size: 14px;">中期学习资料：</p> 
 <ul> 
  <li>securing-rest-api-spring-security:&nbsp;<a href="https://octoperf.com/blog/2018/03/08/securing-rest-api-spring-security/">https://octoperf.com/blog/2018/03/08/securing-rest-api-spring-security/</a> </li> 
 </ul> code:&nbsp;
 <a href="https://github.com/jloisel/securing-rest-api-spring-security">https://github.com/jloisel/securing-rest-api-spring-security</a> 
</div>