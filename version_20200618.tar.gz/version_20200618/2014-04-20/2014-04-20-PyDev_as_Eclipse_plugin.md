#PyDev as Eclipse plugin
###发表时间：2014-04-20
###分类：eclipse,python
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2050177" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2050177</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <div id="urls-for-pydev-as-eclipse-plugin" class="section" style="color: #303030; font-family: Verdana; font-size: 12px; line-height: 18px;"> 
  <h1 style="margin-top: 28px; font-size: 12pt;">Pydev的下载地址：&nbsp;<a href="http://pydev.org/download.html">http://pydev.org/download.html</a> </h1> 
  <h1 style="margin-top: 28px; font-size: 12pt;">URLs for PyDev as Eclipse plugin</h1> 
  <p style="margin: 2px 15px 7px; font-size: 11px; line-height: 1.5em;">Urls to use when updating with the Eclipse update manager:</p> 
  <p style="margin: 2px 15px 7px; font-size: 11px; line-height: 1.5em;">Main:</p> 
  <ul class="simple"> 
   <li><a class="reference external" href="http://pydev.org/updates">http://pydev.org/updates</a></li> 
  </ul> 
  <p style="margin: 2px 15px 7px; font-size: 11px; line-height: 1.5em;">Nightly builds:</p> 
  <ul class="simple"> 
   <li><a class="reference external" href="http://pydev.org/nightly">http://pydev.org/nightly</a></li> 
  </ul> 
 </div> 
 <div id="get-zip-releases" class="section" style="color: #303030; font-family: Verdana; font-size: 12px; line-height: 18px;"> 
  <h1 style="margin-top: 28px; font-size: 12pt;">Get zip releases</h1> 
  <ul class="simple"> 
   <li><a class="reference external" href="http://sourceforge.net/projects/pydev/files/">SourceForge download</a></li> 
  </ul> 
  <p>&nbsp;将下载的&nbsp;PyDev 4.1.0.zip 文件放在 eclipse 的&nbsp;dropins 目录中解压为&nbsp;PyDev 4.1.0 文件夹，重启eclipse就可以使用了。</p> 
 </div> 
</div>