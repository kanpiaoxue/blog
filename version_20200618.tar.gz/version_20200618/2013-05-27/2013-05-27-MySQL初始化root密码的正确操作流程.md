#MySQL初始化root密码的正确操作流程
###发表时间：2013-05-27
###分类：mysql
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/1876536" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/1876536</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <h1 style="margin-bottom: 0px; padding-top: 12px; background-color: transparent; height: 45px; font-size: 22px; line-height: 42px; text-align: center; border-bottom-color: #d8d9d9; border-bottom-width: 1px; border-bottom-style: solid; font-family: 宋体;">MySQL初始化root密码的正确操作流程</h1> 
 <p>&nbsp;</p> 
 <p>&nbsp;</p> 
 <p><a href="http://database.51cto.com/art/201006/203960.htm">http://database.51cto.com/art/201006/203960.htm</a></p> 
 <p>&nbsp;</p> 
 <p><a href="http://www.cnblogs.com/xyzdw/archive/2011/08/11/2135227.html">http://www.cnblogs.com/xyzdw/archive/2011/08/11/2135227.html</a></p> 
 <p>&nbsp;</p> 
 <h3 class="title pre fs1" style="overflow: hidden; font-size: 14px; margin-top: 30px; margin-bottom: 20px; line-height: 24px; font-family: Arial, Helvetica, simsun, u5b8bu4f53; background-color: #d7f2f4;">解决 ERROR 1045 (28000): Access denied for user 'root'@'localhost' (using password: YES) 问题</h3> 
 <p><a href="http://huangyifa163.blog.163.com/blog/static/262875752011127102215790/">http://huangyifa163.blog.163.com/blog/static/262875752011127102215790/</a></p> 
 <p>&nbsp;</p> 
 <h2 class="title content-title" style="margin-bottom: 10px; font-size: 20px; font-family: tahoma, helvetica, 'microsoft yahei', arial; color: #3a3a3a; font-weight: normal; line-height: normal;">linux的mysql下看不到mysql数据库解决方案</h2> 
 <p><a href="http://hi.baidu.com/52happytime/item/e55b820aef61ae324ac4a3ca">http://hi.baidu.com/52happytime/item/e55b820aef61ae324ac4a3ca</a></p> 
</div>