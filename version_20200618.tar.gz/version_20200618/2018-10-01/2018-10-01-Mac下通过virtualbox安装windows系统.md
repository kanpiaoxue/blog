#Mac下通过virtualbox安装windows系统
###发表时间：2018-10-01
###分类：mac,经验,virtualbox
###iteye原始地址：<a href="https://kanpiaoxue.iteye.com/admin/blogs/2431639" target="_blank">https://kanpiaoxue.iteye.com/admin/blogs/2431639</a>

---

<div class="iteye-blog-content-contain" style="font-size: 14px;"> 
 <p>&nbsp;</p> 
 <p>参考地址：&nbsp;<a href="https://blog.csdn.net/jswawawa/article/details/64906345">https://blog.csdn.net/jswawawa/article/details/64906345</a></p> 
 <p>简单来说：</p> 
 <p>1、Mac安装virtualbox软件</p> 
 <p>2、在virtualbox安装Windows7</p> 
 <p>3、在virtualbox的“设备”菜单里面选择“安装增强功能”。这个时候你安装的Windows系统会显示一个光驱，里面是virtualbox的增强内容。选择里面的32位或者64位的安装软件，安装即可。</p> 
 <p>4、安装增强软件之后会让你重启win7，重启之后就可以全屏了。</p> 
</div>